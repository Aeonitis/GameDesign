// GENERATED AUTOMATICALLY FROM 'Assets/Packages/InputControl/Player Controls.inputactions'

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.Utilities;

public class @PlayerControls : IInputActionCollection, IDisposable
{
    public InputActionAsset asset { get; }
    public @PlayerControls()
    {
        asset = InputActionAsset.FromJson(@"{
    ""name"": ""Player Controls"",
    ""maps"": [
        {
            ""name"": ""PlayerInputActionMap"",
            ""id"": ""645d465c-a420-4277-aa52-e9358cf9983e"",
            ""actions"": [
                {
                    ""name"": ""Pass"",
                    ""type"": ""Button"",
                    ""id"": ""268b6d5f-f9de-432f-a5a2-5cd28e475ec5"",
                    ""expectedControlType"": ""Button"",
                    ""processors"": """",
                    ""interactions"": """"
                },
                {
                    ""name"": ""Move"",
                    ""type"": ""PassThrough"",
                    ""id"": ""fb89ff4c-c2f9-4f8e-bae9-407bca911fbd"",
                    ""expectedControlType"": ""Stick"",
                    ""processors"": """",
                    ""interactions"": """"
                }
            ],
            ""bindings"": [
                {
                    ""name"": """",
                    ""id"": ""21a90874-c327-4473-bc05-b6b7a5fe23b5"",
                    ""path"": ""<XInputController>/buttonSouth"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""DS4/XBX controller scheme"",
                    ""action"": ""Pass"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": false
                },
                {
                    ""name"": """",
                    ""id"": ""6c841729-abc0-4e1a-9c93-69fb89f0b63b"",
                    ""path"": ""<Gamepad>/leftStick"",
                    ""interactions"": """",
                    ""processors"": """",
                    ""groups"": ""DS4/XBX controller scheme"",
                    ""action"": ""Move"",
                    ""isComposite"": false,
                    ""isPartOfComposite"": false
                }
            ]
        }
    ],
    ""controlSchemes"": [
        {
            ""name"": ""DS4/XBX controller scheme"",
            ""bindingGroup"": ""DS4/XBX controller scheme"",
            ""devices"": [
                {
                    ""devicePath"": ""<DualShockGamepad>"",
                    ""isOptional"": false,
                    ""isOR"": false
                },
                {
                    ""devicePath"": ""<XInputController>"",
                    ""isOptional"": false,
                    ""isOR"": false
                },
                {
                    ""devicePath"": ""<Gamepad>"",
                    ""isOptional"": false,
                    ""isOR"": false
                }
            ]
        }
    ]
}");
        // PlayerInputActionMap
        m_PlayerInputActionMap = asset.FindActionMap("PlayerInputActionMap", throwIfNotFound: true);
        m_PlayerInputActionMap_Pass = m_PlayerInputActionMap.FindAction("Pass", throwIfNotFound: true);
        m_PlayerInputActionMap_Move = m_PlayerInputActionMap.FindAction("Move", throwIfNotFound: true);
    }

    public void Dispose()
    {
        UnityEngine.Object.Destroy(asset);
    }

    public InputBinding? bindingMask
    {
        get => asset.bindingMask;
        set => asset.bindingMask = value;
    }

    public ReadOnlyArray<InputDevice>? devices
    {
        get => asset.devices;
        set => asset.devices = value;
    }

    public ReadOnlyArray<InputControlScheme> controlSchemes => asset.controlSchemes;

    public bool Contains(InputAction action)
    {
        return asset.Contains(action);
    }

    public IEnumerator<InputAction> GetEnumerator()
    {
        return asset.GetEnumerator();
    }

    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }

    public void Enable()
    {
        asset.Enable();
    }

    public void Disable()
    {
        asset.Disable();
    }

    // PlayerInputActionMap
    private readonly InputActionMap m_PlayerInputActionMap;
    private IPlayerInputActionMapActions m_PlayerInputActionMapActionsCallbackInterface;
    private readonly InputAction m_PlayerInputActionMap_Pass;
    private readonly InputAction m_PlayerInputActionMap_Move;
    public struct PlayerInputActionMapActions
    {
        private @PlayerControls m_Wrapper;
        public PlayerInputActionMapActions(@PlayerControls wrapper) { m_Wrapper = wrapper; }
        public InputAction @Pass => m_Wrapper.m_PlayerInputActionMap_Pass;
        public InputAction @Move => m_Wrapper.m_PlayerInputActionMap_Move;
        public InputActionMap Get() { return m_Wrapper.m_PlayerInputActionMap; }
        public void Enable() { Get().Enable(); }
        public void Disable() { Get().Disable(); }
        public bool enabled => Get().enabled;
        public static implicit operator InputActionMap(PlayerInputActionMapActions set) { return set.Get(); }
        public void SetCallbacks(IPlayerInputActionMapActions instance)
        {
            if (m_Wrapper.m_PlayerInputActionMapActionsCallbackInterface != null)
            {
                @Pass.started -= m_Wrapper.m_PlayerInputActionMapActionsCallbackInterface.OnPass;
                @Pass.performed -= m_Wrapper.m_PlayerInputActionMapActionsCallbackInterface.OnPass;
                @Pass.canceled -= m_Wrapper.m_PlayerInputActionMapActionsCallbackInterface.OnPass;
                @Move.started -= m_Wrapper.m_PlayerInputActionMapActionsCallbackInterface.OnMove;
                @Move.performed -= m_Wrapper.m_PlayerInputActionMapActionsCallbackInterface.OnMove;
                @Move.canceled -= m_Wrapper.m_PlayerInputActionMapActionsCallbackInterface.OnMove;
            }
            m_Wrapper.m_PlayerInputActionMapActionsCallbackInterface = instance;
            if (instance != null)
            {
                @Pass.started += instance.OnPass;
                @Pass.performed += instance.OnPass;
                @Pass.canceled += instance.OnPass;
                @Move.started += instance.OnMove;
                @Move.performed += instance.OnMove;
                @Move.canceled += instance.OnMove;
            }
        }
    }
    public PlayerInputActionMapActions @PlayerInputActionMap => new PlayerInputActionMapActions(this);
    private int m_DS4XBXcontrollerschemeSchemeIndex = -1;
    public InputControlScheme DS4XBXcontrollerschemeScheme
    {
        get
        {
            if (m_DS4XBXcontrollerschemeSchemeIndex == -1) m_DS4XBXcontrollerschemeSchemeIndex = asset.FindControlSchemeIndex("DS4/XBX controller scheme");
            return asset.controlSchemes[m_DS4XBXcontrollerschemeSchemeIndex];
        }
    }
    public interface IPlayerInputActionMapActions
    {
        void OnPass(InputAction.CallbackContext context);
        void OnMove(InputAction.CallbackContext context);
    }
}
