﻿using UnityEngine;

public class EventChannelBaseSO : ScriptableObject
{
	[TextArea] public string description;
}
