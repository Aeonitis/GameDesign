﻿using UnityEngine;

//CreateAssetMenu commented since we don't want to create more than one Initialisation GameSceneSO
// [CreateAssetMenu(fileName = "Initialization", menuName = "Scene Data/Initialization")]
public class InitializationSO : GameSceneSO { }
