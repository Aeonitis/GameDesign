﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RuntimeAnchorBase : ScriptableObject
{
	[TextArea] public string description;
}
